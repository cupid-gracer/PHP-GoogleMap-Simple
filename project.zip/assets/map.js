function MapView() {
    // var isMore = false;
    var geocoder = new google.maps.Geocoder();
    const img_point = 'https://www.postoffice.co.uk/.resources/pol-module-main/img/branch-finder/mylocation.png';
    const img_marker = 'https://icons.iconarchive.com/icons/icons-land/vista-map-markers/128/Map-Marker-Marker-Outside-Pink-icon.png';
    // const img_marker = 'https://icons.iconarchive.com/icons/paomedia/small-n-flat/128/map-marker-icon.png';
    // const img_marker = 'https://icons.iconarchive.com/icons/icons-land/vista-map-markers/128/Map-Marker-Flag-1-Right-Azure-icon.png';
    var bounds = new google.maps.LatLngBounds();
    var currentInfoWindow;
    var map;
    var latlng = new google.maps.LatLng(52.2654532, 2.6694238);
    var myOptions = {
        zoom: 8,
        center: latlng,
        styles: [{
            "featureType": "poi",
            "stylers": [
                { "visibility": "off" }
            ]
        }]
    }
    map = new google.maps.Map(document.getElementById("map"), myOptions);
    let postcode = $("#postcode").val();

    google.maps.event.addListenerOnce(map, 'tilesloaded', function() {
        geocoder.geocode({
            address: postcode,
        }, function(result, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                if (status == 'OK' && result.length > 0) {
                    const marker = new google.maps.Marker({ map: map, icon: img_point });
                    // map.setZoom(15);
                    map.setCenter(result[0].geometry.location);
                    // Set the position of the marker using the place ID and location.
                    marker.setPlace({
                        placeId: result[0].place_id,
                        location: result[0].geometry.location,
                    });
                    marker.setVisible(true)
                }
            }
        });
    });

    let counter = 0;

    cinemas.forEach(cinema => {
        const idx = ++counter;
        if (!isMore) {
            if (idx > 5) return;
        }
        var _postcode = cinema.postcode;
        // var _postcode = postcodes[i]
        google.maps.event.addListenerOnce(map, 'tilesloaded', function() {
            geocoder.geocode({
                address: _postcode,
            }, function(result, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (status == 'OK' && result.length > 0) {
                        var contentString = `<div class="row" style="width:180px; height:100px; text-align:left;">
                                            <div style="font-size: 1.1em;font-weight: bold;">${cinema.cinema}</div>
                                            <div>${ cinema.address1 + ", " + cinema.address2 }</div>
                                            <div>${cinema.postcode}</div>
                                            <div style="color:#e90006">${cinema.distance.toFixed(2)}km</div>
                                            </div>
                                            `;
                        const infowindow = new google.maps.InfoWindow({
                            content: contentString,
                            maxWidth: 400,
                        });

                        const marker = new google.maps.Marker({
                            map: map,
                            icon: {
                                url: img_marker,
                                scaledSize: {
                                    width: 45,
                                    height: 55
                                }
                            },
                            label: {
                                className: 'marker',
                                text: idx.toString(),
                                color: "white",
                                fontSize: '1.2em',
                                fontWeight: 'bold'
                            },
                            position: new google.maps.LatLng(result[0].geometry.location.lat(), result[0].geometry.location.lng())
                        });

                        // google.maps.event.addListener(marker, 'click', function() {
                        //     infoWindow.open(map, marker); //take care with case-sensitiveness
                        // });

                        bounds.extend(marker.position);
                        map.fitBounds(bounds);

                        // google.maps.event.addListener(marker, 'click', (function(marker) {
                        //     return function() {
                        //         infowindow.open(map, marker);
                        //     }

                        // })(marker));
                        // setTimeout(function() { infowindow.close(); }, 5000);

                        marker.addListener("click", () => {
                            if (currentInfoWindow != null) {
                                currentInfoWindow.close();
                            }

                            currentInfoWindow = infowindow;
                            infowindow.open({
                                anchor: marker,
                                map,
                                shouldFocus: true,
                            });
                        });

                        //extend the bounds to include each marker's position
                        // map.setZoom(15);
                        // map.setCenter(result[0].geometry.location);
                        // Set the position of the marker using the place ID and location.
                        marker.setPlace({
                            placeId: result[0].place_id,
                            location: result[0].geometry.location,
                        });
                        marker.setVisible(true)
                    }
                }
            });
        });
    });

}


// This sample requires the Places library. Include the libraries=places
// parameter when you first load the API. For example:
// <script
// src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">
// function initMap() {
//     const map = new google.maps.Map(document.getElementById("map"), {
//         center: { lat: -33.8688, lng: 151.2195 },
//         zoom: 13,
//     });
//     const input = document.getElementById("postcode");
//     // Specify just the place data fields that you need.
//     const autocomplete = new google.maps.places.Autocomplete(input, {
//         fields: ["place_id", "geometry", "name", "formatted_address"],
//     });

//     autocomplete.bindTo("bounds", map);
//     map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

//     const infowindow = new google.maps.InfoWindow();
//     const infowindowContent = document.getElementById("infowindow-content");

//     infowindow.setContent(infowindowContent);

//     const geocoder = new google.maps.Geocoder();
//     const marker = new google.maps.Marker({ map: map });

//     marker.addListener("click", () => {
//         infowindow.open(map, marker);
//     });
//     autocomplete.addListener("place_changed", () => {
//         infowindow.close();

//         const place = autocomplete.getPlace();

//         if (!place.place_id) {
//             return;
//         }

//         geocoder
//             .geocode({ placeId: place.place_id })
//             .then(({ results }) => {
//                 map.setZoom(11);
//                 map.setCenter(results[0].geometry.location);
//                 // Set the position of the marker using the place ID and location.
//                 marker.setPlace({
//                     placeId: place.place_id,
//                     location: results[0].geometry.location,
//                 });
//                 marker.setVisible(true);
//                 infowindowContent.children["place-name"].textContent = place.name;
//                 infowindowContent.children["place-id"].textContent = place.place_id;
//                 infowindowContent.children["place-address"].textContent =
//                     results[0].formatted_address;
//                 infowindow.open(map, marker);
//             })
//             .catch((e) => window.alert("Geocoder failed due to: " + e));
//     });
// }





// var bounds = new google.maps.LatLngBounds();
// var markers = [];
// console.log(markers.length);

// for (let i = 0; i < markers.length; i++) {
//     const marker = markers[i];
//     bounds.extend(marker.position);
//     console.log(marker);
// }

// map.fitBounds(bounds);
// map.panToBounds(bounds);